import { Component } from '@angular/core';

@Component({
  selector: 'app-cadastrar',
  standalone: true,
  imports: [],
  templateUrl: './cadastrar.component.html',
  styleUrl: './cadastrar.component.css'
})
export class CadastrarComponent {

}

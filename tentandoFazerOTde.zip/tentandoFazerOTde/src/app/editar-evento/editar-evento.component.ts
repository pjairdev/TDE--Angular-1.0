import { Component } from '@angular/core';

@Component({
  selector: 'app-editar-evento',
  standalone: true,
  imports: [],
  templateUrl: './editar-evento.component.html',
  styleUrl: './editar-evento.component.css'
})
export class EditarEventoComponent {

}

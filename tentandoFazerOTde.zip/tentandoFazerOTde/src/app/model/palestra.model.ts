export class palestra {
    id: number;
    nome: String;
    dataInicio: String;
    dataTermino: String;
    horario: String;
    palestrante: String;
    vagas: number;  
    descricao: String;
    dataLimite: String;

    constructor(id: number, nome: String, dataInicio: String, dataTermino: String, horario: String, vagas: number, descricao: String, palestrante: String, dataLimite: String){
        this.id = id;
        this.nome = nome;
        this.dataInicio = dataInicio;
        this.dataTermino = dataTermino;
        this.horario    = horario;
        this.vagas  = vagas;
        this.descricao = descricao;
        this.palestrante = palestrante;
        this.dataLimite = dataLimite;
    }
}

import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { Evento } from '../model/evento.model';
import { Router } from '@angular/router';
import { EventoService } from '../service/evento.service';

@Component({
  selector: 'app-evento-list',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './evento-list.component.html',
  styleUrl: './evento-list.component.css'
})

export class EventoListComponent {

  eventos:Array<Evento> = [];
  
  constructor(private router: Router, private eventoService:
    EventoService) {}

    ngOnInit(): void {
      this.atualizarEventos();
    }

    atualizarEventos(){
      this.eventoService.getContatos().subscribe({
      next: (eventos) => {
      this.eventos = eventos;
      },
      error: (erro) => {
      console.log(erro)
      }
      });
      }

  editar(id: number){
    this.router.navigateByUrl('/evento/edit', {state: { idEvento:
    id }})
    }

    remover(id: number){
    this.eventoService.removeContato(id);
    this.atualizarEventos();
    }
}

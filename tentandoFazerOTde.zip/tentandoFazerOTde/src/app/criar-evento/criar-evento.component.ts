import { Component } from '@angular/core';

@Component({
  selector: 'app-criar-evento',
  standalone: true,
  imports: [],
  templateUrl: './criar-evento.component.html',
  styleUrl: './criar-evento.component.css'
})
export class CriarEventoComponent {

}

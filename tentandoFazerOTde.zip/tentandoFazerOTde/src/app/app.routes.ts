import { Routes } from '@angular/router';

import { EventoListComponent } from './evento-list/evento-list.component';
import { MinicursoListComponent } from './minicurso-list/minicurso-list.component';
import { PalestrasListComponent } from './@palestras-list/palestras-list.component';
import { LoginComponent } from './login/login.component';
import { CriarEventoComponent } from './criar-evento//criar-evento.component';
import { CadastrarComponent } from './cadastrar/cadastrar.component';
import { PerfilUsuarioComponent } from './perfil-usuario/perfil-usuario.component';
import { RemoverEventoComponent } from './remover-evento/remover-evento.component';
import { EditarEventoComponent } from './editar-evento/editar-evento.component';

export const routes: Routes = [
    {path: 'evento/list', component: EventoListComponent},
    {path: 'minicurso/list', component: MinicursoListComponent},
    {path: 'palestras/list', component: PalestrasListComponent},
    {path: 'login', component: LoginComponent},
    {path: 'cadastrar', component: CadastrarComponent},
    {path: 'evento/criar', component: CriarEventoComponent},
    {path: 'perfil', component: PerfilUsuarioComponent},
    {path: 'perfil/remover-evento', component: RemoverEventoComponent},
    {path: 'perfil/editar-evento', component: EditarEventoComponent},

];
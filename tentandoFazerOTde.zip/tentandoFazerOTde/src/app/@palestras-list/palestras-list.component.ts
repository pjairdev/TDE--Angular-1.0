import { Component } from '@angular/core';

@Component({
  selector: 'app-palestras-list',
  standalone: true,
  imports: [],
  templateUrl: './palestras-list.component.html',
  styleUrl: './palestras-list.component.css'
})
export class PalestrasListComponent {

}

import { Injectable } from '@angular/core';

import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Evento } from '../model/evento.model';

@Injectable({
providedIn: 'root'
})

export class EventoService {

  private eventosUrl = 'http://localhost:5000/api/v1/evento';
  
  private headers = new HttpHeaders ({"Authorization" : "tokenJWT"})
  
  constructor(private http: HttpClient) { 
    
  }

    getContatos(): Observable<Evento[]> {
          return this.http.get<Evento[]>( `${this.eventosUrl}` ,
          { "headers": this.headers }).pipe(
          map(eventos => {
          return eventos;
          })
      );
    }

    getContatoById(id: number): Observable<Evento> {
        return this.http.get<Evento>(`${this.eventosUrl}/${id}`,
        { "headers": this.headers }).pipe(
        map(evento => {
        return evento;
        })
      );
    }

    addContato(eventoParam: Evento) {
        let eventoJson = {"contato" : JSON.stringify(eventoParam)};
            this.http.post<any>(`${this.eventosUrl}`, eventoJson, { "headers":
            this.headers }).subscribe({
            next: data => {
            return data;
            },
            error: error => {
            console.error('Houve um erro:', error);
            }
      });
    }

    editContato(eventoParam: Evento){
       let eventoJson = {"evento":JSON.stringify(eventoParam)};
          return this.http.put<any>(`${this.eventosUrl}`, eventoJson, { "headers"
          : this.headers }).subscribe({
          next: data => {
          return data;
          },
          error: error => {
          console.error('Houve um erro:', error);
          }
      });
    }

    removeContato(id: number){
          this.http.delete<any>(`${this.eventosUrl}/${id}`, {"headers" :
          this.headers}).subscribe({
          next: data => {
          return data;
          },
          error: error => {
          console.error('Houve um erro:', error);
          }
      });
    }
}
import { Component } from '@angular/core';

@Component({
  selector: 'app-minicurso-list',
  standalone: true,
  imports: [],
  templateUrl: './minicurso-list.component.html',
  styleUrl: './minicurso-list.component.css'
})
export class MinicursoListComponent {

}

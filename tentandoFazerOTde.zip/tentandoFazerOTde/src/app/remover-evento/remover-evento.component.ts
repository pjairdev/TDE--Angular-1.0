import { Component } from '@angular/core';

@Component({
  selector: 'app-remover-evento',
  standalone: true,
  imports: [],
  templateUrl: './remover-evento.component.html',
  styleUrl: './remover-evento.component.css'
})
export class RemoverEventoComponent {

}
